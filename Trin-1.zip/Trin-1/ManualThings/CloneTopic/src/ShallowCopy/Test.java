package ShallowCopy;

public class Test {
	
	public int x;
	public int y;

}
