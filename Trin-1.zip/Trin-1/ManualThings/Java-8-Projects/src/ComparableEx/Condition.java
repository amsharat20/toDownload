package ComparableEx;

public interface Condition {
	
	boolean test(Person p);

}
