package Lambda;

public interface Greeting {
	
	public void perform();

}
