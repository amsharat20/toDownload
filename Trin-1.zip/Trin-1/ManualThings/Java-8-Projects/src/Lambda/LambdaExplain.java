package Lambda;

public class LambdaExplain {
	
	
	
}
