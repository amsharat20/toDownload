package Basics;

public  abstract class AbstractClassShape {

		abstract void draw();  
		
		}  
		
 
	
