package Basics;

//In real scenario, implementation is provided by others i.e. unknown by end user  
class Rectangle extends AbstractClassShape{  
	void draw()
	{
		System.out.println("drawing rectangle");
		}  
}  
