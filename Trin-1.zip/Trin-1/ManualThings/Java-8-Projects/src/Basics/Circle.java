package Basics;

class Circle1 extends AbstractClassShape{  
	void draw()
	{
		System.out.println("drawing circle");
		}  
	}  