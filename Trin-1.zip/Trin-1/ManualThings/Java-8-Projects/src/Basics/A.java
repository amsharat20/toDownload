package Basics;


class A{  
	A get(){
		return this;
	}  
}  