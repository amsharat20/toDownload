package Basics;

public class SuperExPersonMain {

	public static void main(String[] args){  
		Emp e1=new Emp(1,"ankit",45000f);  
		e1.display();  
	}
	
}
