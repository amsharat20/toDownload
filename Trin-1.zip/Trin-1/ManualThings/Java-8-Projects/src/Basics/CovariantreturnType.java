package Basics;

public class CovariantreturnType {

	public static void main(String args[]){  
		new B1().get().message();  
	}  
}  

