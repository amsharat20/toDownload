import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class PointerPrint {

	
	public static void main(String[] args) {
		
		Map<Integer, String> hm = new HashMap<Integer, String>();
		hm.put(5, "5");
		
		
		int n = 4 ;
		
		for (int i=0; i<n ;i ++){
			for (int j=0;j<=i;j++){
				System.out.print("*");
			}
		}
		
		hm.put(1, "5");
		
		Iterator<Map.Entry<Integer, String>> itr = hm.entrySet().iterator();
		
		
		while(itr.hasNext())
        {
             Map.Entry<Integer, String> entry = itr.next();
             System.out.println("Key = " + entry.getKey() +
                                 ", Value = " + entry.getValue());
        }
    
	}
}
