
public class Reversal {
	
	public static void main(String[] args) {
		
		  String a = "tree";
	        char[] c= a.toCharArray();
	        
	        for(char d : c) {
	        	//System.out.println(d);
	        }
	        
	        for(int i=c.length-1; i>=0;i--) {
	        	System.out.print(c[i]);
	        }
	        
	        
	        
	}

}
