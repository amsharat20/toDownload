package Callable;

public class InvalidParamaterException extends Exception {
	
    public InvalidParamaterException(String message) {
        super(message);
    }
}