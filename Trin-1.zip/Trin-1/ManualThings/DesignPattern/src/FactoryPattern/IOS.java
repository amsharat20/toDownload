package FactoryPattern;

public class IOS implements OS {

	@Override
	public void OS() {
		System.out.println("Ios OS");
	}

}
