package FactoryPattern;

public interface OS {

	void OS();
}
