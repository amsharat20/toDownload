package FactoryPattern;

public class WindowsOS implements OS {

	@Override
	public void OS() {
		System.out.println("Windows OS");
		
	}

}
