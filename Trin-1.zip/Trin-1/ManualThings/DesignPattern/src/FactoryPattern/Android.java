package FactoryPattern;

public class Android implements OS{

	@Override
	public void OS() {
		System.out.println("OS - Android");
		
	}

}
