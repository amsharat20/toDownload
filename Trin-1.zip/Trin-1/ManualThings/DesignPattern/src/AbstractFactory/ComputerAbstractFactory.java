package AbstractFactory;

public interface ComputerAbstractFactory {

    public Computer createComputer();

}
