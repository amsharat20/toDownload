package PrototypePattern;

public class PrototypeMain {

	
	public static void main (String[] args) 
    { 
        ColorStore.getColor("BLUE").addColor(); 
        ColorStore.getColor("RED").addColor(); 
    } 
	
	
}
