package AdapterPattern;

public interface Pen {
	
	void write(String str);

}
