Define an interface or abstract class for creating an object but let the subclasses decide which class to instantiate.

Factory Method Pattern allows the sub-classes to choose the type of objects to create.

It promotes the loose-coupling by eliminating the need to bind application-specific classes into the code. That means the code interacts solely with the resultant interface or abstract class, so that it will work with any classes that implement that interface or that extends that abstract class.

Define an interface or abstract class for creating families of related (or dependent) objects but without specifying their concrete sub-classes.

Observer Pattern
An Observer Pattern says that "just define a one-to-one dependency so that when one object changes state, all its dependents are notified and updated automatically".

A State Pattern says that "the class behavior changes based on its state".
In State Pattern, we create objects which represent various states and a context object whose behavior varies as its state object changes.