public class JavaFeaturesStreams {

    public static void main(String[] args) {

   System.out.println("Hi How are you");

    }
}
