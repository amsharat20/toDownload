Why Kubernetes:
With the advent of microservice architecture, users to individually scale key functions of an application and handle millions of customers. 
On top of this, technologies like Docker containers emerged in the enterprise, creating a consistent, portable, and easy way for users to quickly build these microservices.

A service is an abstraction for pods. It provides a  virtual IP (VIP) address. It allow clients to reliably connect to the containers running in the pods, using the Virtual IP address. It is bascially a component that groups together collection of pods.

To display services under kubernetes, you can run the below command:
$kubectl get services

ReplicationController makes sure that a specified number of pod replicas are running at any point of time. 
Specifically ReplicationController ensures that a pod or set of pods are homogeneous in nature and are always up and running.

Every time you create a Deployment, the deployment creates a ReplicaSet and delegates creating (and deleting) the Pods.
The Deployment knows that the two Pods cant coexist in the same ReplicaSet, so it creates a second ReplicaSet to hold version 2.
Keeping the previous ReplicaSets around is a convenient mechanism to roll back to a previously working version of your app.

By default Kubernetes stores the last 10 ReplicaSets and lets you roll back to any of them.
The kubectl scale command enables the ability to instantly change the number of replicas needed for running an application.


Pods
Pods are the smallest units that Kubernetes administers. It constitutes a set of containers.
It shares a single IP address and all the resources, such as storage and memory, among every container within it.
 A pod can have a single container when the service or application is a single process.

Deployments
Kubernetes deployments determine the scale at which one wants to run an application, such as how the pods need to be replicated on the Kubernetes nodes,
the desired number of pod replicas to be run, and the desired update strategy for the deployment.

Services
If a pod dies, Kubernetes replaces it to prevent any downtime. A service is the only interface that the application consumers deal with.
When pods are changed, their internal names and IPs might change as well.

A service exposes a single IP address or machine name linked to pods whose numbers and names are unreliable.
It ensures that nothing appears changed to the outside network.


Nodes
A Kubernetes node collects, runs, and manages pods that function together.

The Kubernetes Control Plane
The Kubernetes control plane is the main entry point for users and administrators to handle the management of various nodes.
HTTP calls or command-line scripts are used to assign operations to it. How Kubernetes interacts with applications is controlled by the control plane.

Cluster
The above components put together in a single unit is referred to as a cluster.

Kubernetes Components:

The control plane and the individual nodes consist of three main components each.

Control plane

API Server
The Kubernetes API server validates and configures data for API objects, including pods, replication controllers, services, etc. It serves REST operations and provides the frontend to the cluster’s shared state through which all other components communicate.

Scheduler
The scheduler assigns work to the nodes, keeps track of the capacity of resources, and ensures that a worker node’s operation is within the right threshold.

Controller Manager
The controller manager ensures that a cluster’s shared state is operating in the desired manner. It monitors various controllers, which respond to events.

Worker Node Components:

Kubelet
A kubelet keeps track of the state of a pod and ensures that every container is operating well.

Kube proxy
The kube proxy is a network proxy that maintains network rules on nodes. It sends requests for work to the appropriate containers.

etcd
This etcd component manages and holds the critical data that distributed systems require to operate. It is an open-source distributed key-value store that is used to share the state of a cluster. It helps with the setup of the overlay network for containers.