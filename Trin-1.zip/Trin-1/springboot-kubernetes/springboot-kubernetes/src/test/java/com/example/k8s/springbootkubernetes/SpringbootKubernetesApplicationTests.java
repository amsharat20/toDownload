package com.example.k8s.springbootkubernetes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootKubernetesApplicationTests {

	@Test
	void contextLoads() {
	}

}
