package com.herin.management.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table (name = "printed_circuit_board ")
public class Pcb {

	@Id
    @GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
    @Column(name = "transaction_id", columnDefinition = "BINARY(16)")
	private String transaction_id;
	
	@Column(name="is_pcb")
	private Boolean is_pcb;
	
	@Column(name="size_x")
	private int size_x;
	
	@Column(name="size_y")
	private int size_y;
	
	@Column(name="layer")
	private String layer;
	
	@Column(name="thickness")
	private float thickness;
	
	@Column(name="surface_finish")
	private String surface_finish;
	
	@Column(name="lead_time")
	private String lead_time;
	
	@Column(name="mask_color")
	private String mask_color;
	
	@Column(name="quantity")
	private int quantity;
	
	@Column(name="material")
	private String material;
	
	@Column(name="finish_copper")
	private String finish_copper;
	
	@Column(name="legend_color")
	private String legend_color;
	
	@Column(name="separation_by")
	private String separation_by;
	
	@Column(name="panelup_x")
	private int panelup_x;
	
	@Column(name="panelup_y")
	private int panelup_y;
	
	@Column(name="sidestrip_x")
	private int sidestrip_x;
	
	@Column(name="sidestrip_y")
	private int sidestrip_y;
	
	@Column(name="order_price")
	private double order_price;
	
	@Column(name="shipping_price")
	private double shipping_price;
	
	@Column(name="email_id")
	private String email_id;
	
	@Column(name="Phone_number")
	private long Phone_number;
	
	@Column(name="name")
	private String name;
	
	@Column(name="gerber_file")
	@Lob
	private byte[] gerber_file;

	public Pcb() {
		
	}
	
	public Pcb(Boolean is_pcb, int size_x, int size_y, String layer, float thickness,
			String surface_finish, String lead_time, String mask_color, int quantity, String material,
			String finish_copper, String legend_color, String separation_by, int panelup_x, int panelup_y,
			int sidestrip_x, int sidestrip_y, double order_price, double shipping_price, String email_id,
			long phone_number, String name, byte[] gerber_file) {
		super();
		this.transaction_id = transaction_id;
		this.is_pcb = is_pcb;
		this.size_x = size_x;
		this.size_y = size_y;
		this.layer = layer;
		this.thickness = thickness;
		this.surface_finish = surface_finish;
		this.lead_time = lead_time;
		this.mask_color = mask_color;
		this.quantity = quantity;
		this.material = material;
		this.finish_copper = finish_copper;
		this.legend_color = legend_color;
		this.separation_by = separation_by;
		this.panelup_x = panelup_x;
		this.panelup_y = panelup_y;
		this.sidestrip_x = sidestrip_x;
		this.sidestrip_y = sidestrip_y;
		this.order_price = order_price;
		this.shipping_price = shipping_price;
		this.email_id = email_id;
		Phone_number = phone_number;
		this.name = name;
		this.gerber_file = gerber_file;
	}

	public String getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}

	public Boolean getIs_pcb() {
		return is_pcb;
	}

	public void setIs_pcb(Boolean is_pcb) {
		this.is_pcb = is_pcb;
	}

	public int getSize_x() {
		return size_x;
	}

	public void setSize_x(int size_x) {
		this.size_x = size_x;
	}

	public int getSize_y() {
		return size_y;
	}

	public void setSize_y(int size_y) {
		this.size_y = size_y;
	}

	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public float getThickness() {
		return thickness;
	}

	public void setThickness(float thickness) {
		this.thickness = thickness;
	}

	public String getSurface_finish() {
		return surface_finish;
	}

	public void setSurface_finish(String surface_finish) {
		this.surface_finish = surface_finish;
	}

	public String getLead_time() {
		return lead_time;
	}

	public void setLead_time(String lead_time) {
		this.lead_time = lead_time;
	}

	public String getMask_color() {
		return mask_color;
	}

	public void setMask_color(String mask_color) {
		this.mask_color = mask_color;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getFinish_copper() {
		return finish_copper;
	}

	public void setFinish_copper(String finish_copper) {
		this.finish_copper = finish_copper;
	}

	public String getLegend_color() {
		return legend_color;
	}

	public void setLegend_color(String legend_color) {
		this.legend_color = legend_color;
	}

	public String getSeparation_by() {
		return separation_by;
	}

	public void setSeparation_by(String separation_by) {
		this.separation_by = separation_by;
	}

	public int getPanelup_x() {
		return panelup_x;
	}

	public void setPanelup_x(int panelup_x) {
		this.panelup_x = panelup_x;
	}

	public int getPanelup_y() {
		return panelup_y;
	}

	public void setPanelup_y(int panelup_y) {
		this.panelup_y = panelup_y;
	}

	public int getSidestrip_x() {
		return sidestrip_x;
	}

	public void setSidestrip_x(int sidestrip_x) {
		this.sidestrip_x = sidestrip_x;
	}

	public int getSidestrip_y() {
		return sidestrip_y;
	}

	public void setSidestrip_y(int sidestrip_y) {
		this.sidestrip_y = sidestrip_y;
	}

	public double getOrder_price() {
		return order_price;
	}

	public void setOrder_price(double order_price) {
		this.order_price = order_price;
	}

	public double getShipping_price() {
		return shipping_price;
	}

	public void setShipping_price(double shipping_price) {
		this.shipping_price = shipping_price;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public long getPhone_number() {
		return Phone_number;
	}

	public void setPhone_number(long phone_number) {
		Phone_number = phone_number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public byte[] getGerber_file() {
		return gerber_file;
	}

	public void setGerber_file(byte[] gerber_file) {
		this.gerber_file = gerber_file;
	}

	@Override
	public String toString() {
		return "Pcb [transaction_id=" + transaction_id + ", is_pcb=" + is_pcb + ", size_x=" + size_x + ", size_y="
				+ size_y + ", layer=" + layer + ", thickness=" + thickness + ", surface_finish=" + surface_finish
				+ ", lead_time=" + lead_time + ", mask_color=" + mask_color + ", quantity=" + quantity + ", material="
				+ material + ", finish_copper=" + finish_copper + ", legend_color=" + legend_color + ", separation_by="
				+ separation_by + ", panelup_x=" + panelup_x + ", panelup_y=" + panelup_y + ", sidestrip_x="
				+ sidestrip_x + ", sidestrip_y=" + sidestrip_y + ", order_price=" + order_price + ", shipping_price="
				+ shipping_price + ", email_id=" + email_id + ", Phone_number=" + Phone_number + ", name=" + name
				+ ", gerber_file=" + gerber_file + "]";
	}
	
}
