package com.herin.management.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.herin.management.model.Pcb;
import com.herin.management.repository.PcbRepository;




@Service
public class PcbService {
	
	@Autowired
	private PcbRepository pcbRepository;
	
	public List<Pcb> getAllEmployees(){
		List<Pcb> pcb = (List<Pcb>)pcbRepository.findAll(); 
		return pcb;
	}
	
	
	public void addPcb(Pcb pcb) throws UnsupportedEncodingException {
		pcbRepository.save(pcb);
	}


	public void store(MultipartFile file, Pcb pcb) throws IOException {
	    System.out.println(pcb.getPhone_number());
	    System.out.println(pcb.getIs_pcb());
	    System.out.println("transaction id " +pcb.getTransaction_id());
	    System.out.println("getGerber_file  " +file.getBytes());
	    pcb.setGerber_file(file.getBytes());
	    System.out.println("Inside repository");
	    pcbRepository.save(pcb);
	}

	
	public Optional<Pcb> getPcb(String transaction_id){
		  return pcbRepository.findById(transaction_id);
		  }

	public List<Pcb> getAllPcbs() {
		List<Pcb> pcb = (List<Pcb>)pcbRepository.findAll(); 
		return pcb;
	}
	

}
