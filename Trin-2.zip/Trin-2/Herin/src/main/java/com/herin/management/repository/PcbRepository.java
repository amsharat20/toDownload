package com.herin.management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.herin.management.model.Pcb;

@Repository
public interface PcbRepository extends JpaRepository<Pcb, String>{

	
}
