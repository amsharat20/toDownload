package com.herin.management.controller;


import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.herin.management.exception.ErrorResponse;
import com.herin.management.model.ConfigProperties;
import com.herin.management.model.Pcb;
import com.herin.management.service.PcbService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RequestMapping("/api/v1")
@Api(value = "Herin Management APIs")

@RestController
public class PcbController {

	static final Logger logger = LogManager.getLogger(PcbController.class.getName());

	@Autowired
	private PcbService pcbService;

	@Autowired
	private ConfigProperties configProperties;

	/*
	 * Add PCB details
	 */

	@ApiOperation(hidden = true, value = "") 
	@PostMapping("/pcb")
	public ResponseEntity<Object> addPcb(
			String jsonFileVo,
			@RequestParam("file") MultipartFile file) throws Exception {

		Pcb pcb = new ObjectMapper().readValue(jsonFileVo, Pcb.class);
		logger.info("PCB:" + pcb.getPhone_number());
		logger.info("PCB:" + pcb.getIs_pcb());
		Pcb returnResult = null;

		boolean checkEmail = validateEmail(pcb.getEmail_id());
		boolean checkPhoneNumber = validatePhoneNumber(pcb.getPhone_number());

		if(!checkEmail) {
			throw new Exception("Email is not Valid");
		}
		if(!checkPhoneNumber) {
			throw new Exception("PhoneNumber is not Valid");
		}

		try {
			logger.info("Received request-body for PCB calcuator " + pcb);
			returnResult = pcbService.store(file,pcb);
		} catch (Exception e) {
			ErrorResponse error = new ErrorResponse("Entry Updation Failed. Server may be down. Try after sometime" +e.getMessage());
			return new ResponseEntity<Object>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		System.out.println("EMAIL " +configProperties.getEmail());
		if (returnResult != null) {
			sendMail(pcb.getEmail_id(),pcb.getTransaction_id(),configProperties.getEmail(),configProperties.getPassword(),configProperties.getHost(),
					configProperties.getPort());
		}

		return new ResponseEntity<Object>("Entry done successfully ", HttpStatus.CREATED);
	}


	/*
	 * Displaying All Available PCBS
	 */
	@ApiOperation("Display All PCB Transactions")
	@GetMapping("/pcbs")
	public List<Pcb> display_All_Transactions()  {
		logger.info("Received API to fetch all pcbs ");
		List<Pcb> pcb = pcbService.getAllPcbs();
		return pcb;
	}


	/*
	 * Downloading the Gerber File
	 */
	@ApiOperation("Download the Gerber file")
	@GetMapping("/pcb/{transactionId}")
	public ResponseEntity<Object> download_Gerber_File(@PathVariable String transactionId) {

		// Load file from database
		Optional<Pcb> pcb = pcbService.getPcb(transactionId);

		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=gerber_file");
		header.add("Cache-Control", "no-cache, no-store, must-revalidate");
		header.add("Pragma", "no-cache");
		header.add("Expires", "0");

		return ResponseEntity.ok()
				.headers(header)
				.contentLength(pcb.get().getGerber_file().length)
				.contentType(MediaType.APPLICATION_OCTET_STREAM)
				.body(new ByteArrayResource( pcb.get().getGerber_file()));
	}


	/*
	 * Displaying the Gerber File Details
	 */
	@ApiOperation("Display Gerber File Details")
	@GetMapping("/pcbDetails/{transactionId}")
	public ResponseEntity<Object> display_Gerber_File_Details(@PathVariable String transactionId) {

		// Load file from database
		Optional<Pcb> pcb = pcbService.getPcb(transactionId);

		return ResponseEntity.ok()
				.body(new ByteArrayResource( pcb.get().getGerber_file()));
	}


	private boolean validatePhoneNumber(long phone_number) {
		Pattern p = Pattern.compile("(0/91)?[7-9][0-9]{9}");
		Matcher m = p.matcher(String.valueOf(phone_number));
		return (m.find() && m.group().equals(String.valueOf(phone_number)));
	}

	private boolean validateEmail(String emailCheck) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
				"[a-zA-Z0-9_+&*-]+)*@" + 
				"(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
				"A-Z]{2,7}$"; 
		Pattern pat = Pattern.compile(emailRegex); 
		if (emailCheck == null) {
			return false; 
		} else {
			return pat.matcher(emailCheck).matches(); 
		}
	}

	public static void sendMail(String receipient, String id, String email, String pwd, String host, String port) throws AddressException, MessagingException {
		Properties prop = new Properties();
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.smtp.starttls.enable", "true");
		prop.put("mail.smtp.host", host );
		prop.put("mail.smtp.port", port);

		Session session =  Session.getInstance(prop, new Authenticator() {
			@Override
			protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
				return new javax.mail.PasswordAuthentication(email, pwd);
			}
		});

		Message message = prepareMessage(session,email,receipient,id); 

		Transport.send(message);
		logger.info("E-Mail sent successfully");
	}

	private static Message prepareMessage(Session session, String email, String receipient, String id) throws AddressException, MessagingException {
		String htmlcode = "<h1> Herin - One stop for PCBs </h1>";
		Message m = new MimeMessage(session);
		m.setFrom(new InternetAddress(email));
		m.setRecipient(Message.RecipientType.TO, new InternetAddress(receipient));
		m.setSubject("Status for the Order");
		m.setText("Order received with Tranaction Id " +id);
		m.setContent(htmlcode, "text/html");
		return m;
	}
}


