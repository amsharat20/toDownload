

read


write


concurrent requests

****************************

(msging BRoker)
______
INGRESS
**************************     shell-scipt

1 pod: ( kubernetes)



func main (){
type RoundRobin struct {
curr int
pool []chan
req chan int
}

func newFunc() *RoundRobin {
r := &RoundRobin {
curr :=0
pool : []chan {channme1, ...}
}

len(pool)

for range {
 go worker(jobs, results)

}


return r

}



go workers



jobs := make(chan int, 100)
results := make (chan, 300)



go worker(jobs, results)
go worker(jobs, results)
go worker(jobs, results)


}

func worker ( ){
  
}


func receiver( jobs <- chan int  , resultset chan <- int){

 
     for x , open := range jobs {
         
      fmt. println("test")

      }
                  

}   
 

}


func requestsHandling() {

//requets takeplace

for {
    msg, open := <-jobs1
     
 if !open {
        for {
           select  {
                case c2 := <- jobs1
                


}




*****************************************






 