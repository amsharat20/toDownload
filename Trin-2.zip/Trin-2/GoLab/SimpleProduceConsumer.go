package main

import (
	"fmt"
	"time"
)

var doneChannel = make(chan bool)
var msgsChannel = make(chan int)

func produce() {
	for i := 0; i < 4; i++ {
		fmt.Println("sending", i)
		msgsChannel <- i

	}
	fmt.Println("Before closing channel")
	close(msgsChannel)
	fmt.Println("Before passing true to done")
	doneChannel <- true
}

func consume() {
	for msg := range msgsChannel {
		fmt.Println("Consumer: ", msg)
		time.Sleep(100 * time.Millisecond)

	}
}

func main() {
	go produce()
	go consume()
	// Finish the program when the production is done
	<-doneChannel
	fmt.Println("After calling DONE")
}
