package main

import "fmt"

var unSorted [5]int = [5]int{2, 4, 7, 5, 9}

func bubbleSort(input [5]int) {
	n := 5
	swapped := true
	for swapped {
		swapped = false
		for i := 1; i < n; i++ {
			if input[i-1] > input[i] {
				fmt.Println("Swapping")
				input[i], input[i-1] = input[i-1], input[i]
				swapped = true
			}
		}
	}
	fmt.Println(input)
}

func main() {
	bubbleSort(unSorted)
}
