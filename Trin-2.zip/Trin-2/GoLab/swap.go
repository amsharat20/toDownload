package main

import (
	"fmt"
)

var c, python bool

func main() {
	fmt.Println("I am Sharat")
	a, b := swap("I am ", "Sharat")
	fmt.Println(a, b)

	var i int
	fmt.Println(i, c, python)

	v := 42
	fmt.Printf("V is of type %T ", v)
}

func swap(x, y string) (string, string) {
	return y, x
}
