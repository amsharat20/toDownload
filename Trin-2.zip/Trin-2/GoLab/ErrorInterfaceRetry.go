package main

import (
	"errors"
	"fmt"
	"net/http"
	"os"
)

type RequestError struct {
	StatusCode int
	Err        error
}

//Defining the Error method
func (r *RequestError) Error() string {
	return r.Err.Error

}

func (r *RequestError) Temporary() bool {
	return r.StatusCode == http.StatusServiceUnavailable
}

func doRequest() error {
	return &RequestError{
		StatusCode: 503,
		Err:        errors.New("Service Unavailable"),
	}
}

func main() {

	err := doRequest()

	if err != nil {
		fmt.Println(err)
		re, ok := err.(*RequestError)
		if ok {
			if re.Temporary() {
				fmt.Println("Request can be tried again")
			} else {
				fmt.Println("Cannot Try Request")
			}
		}
		os.Exit(1)
	}
	fmt.Println("Success")

}
