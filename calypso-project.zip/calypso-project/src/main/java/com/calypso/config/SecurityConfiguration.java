package com.calypso.config;

public class SecurityConfiguration{
	/* @Override
	    protected void configure(HttpSecurity httpSecurity) throws Exception {
	        httpSecurity.authorizeRequests().antMatchers("/").permitAll();
	}*/

}
