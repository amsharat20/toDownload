package com.calypso.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.calypso.manager.MongoConnectManager;
import com.calypso.manager.MongoDeleteManager;
import com.calypso.manager.MongoInsertManager;
import com.calypso.manager.MongoUpdateManager;
import com.calypso.request.MongoConnectionRequest;
import com.calypso.request.MongoDeleteRequest;
import com.calypso.request.MongoInsertRequest;
import com.calypso.request.MongoUpdateRequest;
import com.calypso.response.MongoConnectionResponse;
import com.calypso.response.MongoDeleteResponse;
import com.calypso.response.MongoInsertResponse;
import com.calypso.response.MongoUpdateResponse;

@RestController
@RequestMapping("api/v1/calypso/MongoController")

public class MongoController {
	private Logger logger = Logger.getLogger(MongoController.class);

	@Autowired
	MongoConnectManager mongoConnectManager;
	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	@ResponseBody
	
	public ResponseEntity<?> mongoConnectManager(	
			@Validated @RequestBody(required = true) MongoConnectionRequest mongoConnectionRequest) {
		MongoConnectionResponse response = new MongoConnectionResponse();
		logger.debug("Debug- > Mongo DB Logging for calypso ************** ");
		try {			
			logger.debug("MongoConnectionRequest request username ---> " +mongoConnectionRequest.getUsername());
			logger.debug("MongoConnectionRequest request password ---> " +mongoConnectionRequest.getPassword());
			if(response.getConnectionResponse().equalsIgnoreCase("SUCCESS")){
				System.out.println("SUCCESS");
			} else {
				System.out.println("FAILURE");
			}
			response = mongoConnectManager.connectionResponse(mongoConnectionRequest);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<MongoConnectionResponse>(response,  HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<MongoConnectionResponse>(response, HttpStatus.OK);
	}
	

	//Insert Records into Mongo DB
	
	@Autowired
	MongoInsertManager mongoInsertManager;
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	@ResponseBody
	
	public ResponseEntity<?> mongoInsertManager(	
			@Validated @RequestBody(required = true) MongoInsertRequest mongoInsertRequest) {
		MongoInsertResponse response = new MongoInsertResponse();
		logger.debug("Debug- > Mongo DB Logging for calypso ************** ");
		try {			

			response = mongoInsertManager.insertResponse(mongoInsertRequest);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<MongoInsertResponse>(response,  HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<MongoInsertResponse>(response, HttpStatus.OK);
	}
	
	
	//Update Records into Mongo DB
	
	@Autowired
	MongoUpdateManager mongoUpdateManager;
	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	@ResponseBody
	
	public ResponseEntity<?> mongoUpdatetManager(	
			@Validated @RequestBody(required = true) MongoUpdateRequest mongoUpdateRequest) {
		MongoUpdateResponse response = new MongoUpdateResponse();
		logger.debug("Debug- > Mongo DB Logging for calypso ************** ");
		try {			

			response = mongoUpdateManager.updateResponse(mongoUpdateRequest);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<MongoUpdateResponse>(response,  HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<MongoUpdateResponse>(response, HttpStatus.OK);
	}
	
	

	//Delete Records from Mongo DB
	
	@Autowired
	MongoDeleteManager mongoDeleteManager;
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	@ResponseBody
	
	public ResponseEntity<?> mongoDeletetManager(	
			@Validated @RequestBody(required = true) MongoDeleteRequest mongoDeleteRequest) {
		MongoDeleteResponse response = new MongoDeleteResponse();
		logger.debug("Debug- > Mongo DB Logging for calypso ************** ");
		try {			

			response = mongoDeleteManager.deleteResponse(mongoDeleteRequest);
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ResponseEntity<MongoDeleteResponse>(response,  HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<MongoDeleteResponse>(response, HttpStatus.OK);
	}
	
	
	
}
