package com.calypso.response;

public class MongoDeleteResponse {

}
