package com.calypso.manager;

import com.calypso.request.MongoUpdateRequest;
import com.calypso.response.MongoUpdateResponse;

public interface MongoUpdateManager {

	MongoUpdateResponse updateResponse(MongoUpdateRequest mongoUpdateRequest) throws Exception;

}
