package com.calypso.manager;

import com.calypso.request.MongoConnectionRequest;
import com.calypso.response.MongoConnectionResponse;

public interface MongoConnectManager {
	
	MongoConnectionResponse connectionResponse(MongoConnectionRequest mongoConnectionResponse);
	
	

}
