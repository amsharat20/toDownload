package com.calypso.manager;

import com.calypso.request.MongoDeleteRequest;
import com.calypso.request.MongoInsertRequest;
import com.calypso.response.MongoDeleteResponse;
import com.calypso.response.MongoInsertResponse;
import org.apache.log4j.Logger;

public class MongoDeleteManagerImpl implements MongoDeleteManager {

	MongoInsertResponse response = new MongoInsertResponse();
	private Logger logger = Logger.getLogger(MongoDeleteManagerImpl.class);

	
	
	@Override
	public MongoDeleteResponse deleteResponse(MongoDeleteRequest mongoDeleteRequest) throws Exception {
		
		logger.debug("Debug- > Insert Record starting now ************** ");
		
		
		return null;
	}

}
