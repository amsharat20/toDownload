package com.calypso.request;

public class MongoDeleteRequest {

}
